from transformers import AutoTokenizer, AutoModelForCausalLM
import torch, time
model_name = "Qwen/CodeQwen1.5-7B"

start = time.time()
tokenizer = AutoTokenizer.from_pretrained(model_name, token=True)
model = AutoModelForCausalLM.from_pretrained(
        model_name,
            device_map="auto",
                dtype=torch.float16,
                    token=True
)

prompt = ("""
    from typing import List
 
def has_close_elements(numbers: List[float], threshold: float) -> bool:
    """""" Check if in given list of numbers, are any two numbers closer to each other than
    given threshold.
    >>> has_close_elements([1.0, 2.0, 3.0], 0.5)
    False
    >>> has_close_elements([1.0, 2.8, 3.0, 4.0, 5.0, 2.0], 0.3)
    True
    """""""
    """
)

inputs = tokenizer(prompt, return_tensors="pt")
inputs = {k: v.to(model.device) for k, v in inputs.items() if k != "token_type_ids"}

print("Running Inference...")

outputs = model.generate(
        **inputs,
            max_new_tokens=200,
                eos_token_id=tokenizer.eos_token_id,
                    pad_token_id=tokenizer.eos_token_id,
)

result = tokenizer.decode(outputs[0], skip_special_tokens=True)
print("\nGenerated Code:\n")
print(result.strip())
print(f"\nTime taken: {time.time() - start:.2f}s")
print(f"\nGPU memory allocated: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
print(model_name)