import streamlit as st
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
import pandas as pd
import re
from typing import Dict, List, Optional
import gc
from datetime import datetime
import json
import multiprocessing
from multiprocessing import Process, Queue

# ── Model configs ─────────────────────────────────────────────────────────────
GEMMA_MODEL_NAME    = "CodeGemma 7B Instruct"
GEMMA_MODEL_PATH    = "google/codegemma-7b-it"

LLAMA_MODEL_NAME    = "Code Llama 7B Instruct"
LLAMA_MODEL_PATH    = "codellama/CodeLlama-7b-Instruct-hf"

DEEPSEEK_MODEL_NAME = "DeepSeek Coder 7B Instruct"
DEEPSEEK_MODEL_PATH = "deepseek-ai/deepseek-coder-7b-instruct-v1.5"

DATASET_PATH = "/home/demouser/Desktop/121336311/McEval DataSet/McEval_Generation_Tasks.csv"


# ══════════════════════════════════════════════════════════════════════════════
# DATASET
# ══════════════════════════════════════════════════════════════════════════════

def load_task_2() -> pd.Series:
    df = pd.read_csv(DATASET_PATH)
    return df.iloc[1]  # task 2, 0-indexed


# ══════════════════════════════════════════════════════════════════════════════
# TEST EXECUTION  (exact logic from your individual benchmark scripts)
# ══════════════════════════════════════════════════════════════════════════════

def _execute_test_in_process(code_to_test: str, test_code: str, entry_point: str, result_queue: Queue):
    result = {'passed': False, 'error': None, 'code_tested': code_to_test}
    try:
        namespace = {}
        exec("from typing import List, Dict, Tuple, Optional, Union, Any", namespace)
        try:
            exec(code_to_test, namespace)
        except SyntaxError as e:
            result['error'] = f"Syntax error in generated code: {str(e)}"
            result_queue.put(result); return
        except Exception as e:
            result['error'] = f"Error executing generated code: {str(e)}"
            result_queue.put(result); return
        if entry_point not in namespace:
            result['error'] = f"Function '{entry_point}' not found in code. Found: {list(namespace.keys())}"
            result_queue.put(result); return
        try:
            exec(test_code, namespace)
        except AssertionError as e:
            result['error'] = f"Test assertion failed: {str(e)}"
            result_queue.put(result); return
        except Exception as e:
            result['error'] = f"Error running tests: {str(e)}"
            result_queue.put(result); return
        result['passed'] = True
        result_queue.put(result)
    except Exception as e:
        result['error'] = f"Unexpected error in subprocess: {str(e)}"
        result_queue.put(result)


def run_unit_test(code: str, test_code: str, entry_point: str, timeout: int = 40) -> Dict:
    """Run unit tests on generated code with timeout using multiprocessing"""
    result = {
        'passed': False,
        'error': None,
        'code_tested': None
    }

    try:
        # Extract code from various wrapping formats (same logic as working 3-model script)
        code_to_test = code.strip()

        # Skip if code is just "PASS"
        if 'PASS' in code_to_test.upper() and len(code_to_test) < 50:
            result['error'] = "Code is PASS, cannot test"
            return result

        # Step 1: Extract from <solution> tags if present
        solution_match = re.search(r'<solution>(.*?)</solution>', code_to_test, re.DOTALL)
        if solution_match:
            code_to_test = solution_match.group(1).strip()

        # Step 2: Remove >>> prefix if present
        if code_to_test.startswith('>>>'):
            code_to_test = code_to_test[3:].strip()

        # Step 3: Extract from markdown code fence if present
        fence_match = re.search(r'```(?:python)?\s*\n(.*?)\n```', code_to_test, re.DOTALL)
        if fence_match:
            code_to_test = fence_match.group(1).strip()
        else:
            # Try alternative: just strip the fences manually
            lines = code_to_test.split('\n')
            cleaned_lines = []
            in_code = False

            for line in lines:
                stripped = line.strip()

                if stripped.startswith('```'):
                    in_code = not in_code
                    continue

                if in_code:
                    cleaned_lines.append(line)
                elif line and not re.match(r'^[A-Z][a-z\s,]+', stripped):
                    cleaned_lines.append(line)

            if cleaned_lines:
                code_to_test = '\n'.join(cleaned_lines).strip()

        result['code_tested'] = code_to_test

        # Check if code is empty
        if not code_to_test or len(code_to_test.strip()) == 0:
            result['error'] = "Generated code is empty after extraction"
            return result

        # Create a queue to receive results from the subprocess
        result_queue = Queue()

        # Create and start the process
        process = Process(target=_execute_test_in_process, args=(code_to_test, test_code, entry_point, result_queue))
        process.start()

        # Wait for the process to complete or timeout
        process.join(timeout=timeout)

        if process.is_alive():
            # Process is still running after timeout - terminate it
            process.terminate()
            process.join()
            result['error'] = f"Infinite loop detected: Test execution exceeded {timeout} seconds timeout"
            return result

        # Check if we got a result from the queue
        if not result_queue.empty():
            result = result_queue.get()
        else:
            # Process finished but no result - likely crashed
            result['error'] = "Test process terminated unexpectedly without returning a result"

    except Exception as e:
        result['error'] = f"Unexpected error: {str(e)}"

    return result


# ══════════════════════════════════════════════════════════════════════════════
# MODEL LOADING / CLEANUP  (exact logic from your scripts)
# ══════════════════════════════════════════════════════════════════════════════

def load_model_safe(model_name: str, model_path: str):
    import os
    os.environ["ACCELERATE_USE_FSDP"] = "false"
    os.environ["ACCELERATE_USE_DEEPSPEED"] = "false"
    try:
        st.write(f"Loading {model_name}...")
        tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        model = AutoModelForCausalLM.from_pretrained(
            model_path,
            trust_remote_code=True,
            low_cpu_mem_usage=False,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        )
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model = model.to(device)
        st.write(f"{model_name} loaded on {device}")
        return tokenizer, model, device
    except Exception as e:
        st.error(f"Error loading {model_name}: {e}")
        return None, None, None


def cleanup_model(model, tokenizer):
    if model is not None:
        del model
    if tokenizer is not None:
        del tokenizer
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


# ══════════════════════════════════════════════════════════════════════════════
# GENERATION  (exact logic from your scripts)
# ══════════════════════════════════════════════════════════════════════════════

def generate_response(tokenizer, model, device, prompt: str, temperature: float = 0.3, max_tokens: int = 512) -> Optional[str]:
    try:
        with torch.no_grad():
            inputs = tokenizer(prompt, return_tensors="pt").to(device)
            if 'token_type_ids' in inputs:
                inputs.pop('token_type_ids')
            prompt_length = inputs["input_ids"].shape[1]
            outputs = model.generate(
                **inputs,
                max_new_tokens=max_tokens,
                temperature=temperature if temperature > 0 else 0.001,
                do_sample=temperature > 0,
                top_k=10,
                pad_token_id=tokenizer.pad_token_id if tokenizer.pad_token_id else tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
            generated_tokens = outputs[0][prompt_length:]
            result = tokenizer.decode(generated_tokens, skip_special_tokens=True)
            del inputs
            del outputs
            torch.cuda.empty_cache()
            return result.strip() if result.strip() else None
    except Exception as e:
        st.error(f"Error generating response: {str(e)}")
        return None


# ══════════════════════════════════════════════════════════════════════════════
# PROMPTS  (exact formats from your individual benchmark scripts)
# ══════════════════════════════════════════════════════════════════════════════

def make_gemma_solo_prompt(task_prompt: str) -> str:
    return f"""<start_of_turn>user
{task_prompt}

Please provide a complete solution to the task. Encapsulate your solution within <solution> tags.

IMPORTANT: Do NOT add any explanations or commentary after the </solution> tag. End your response immediately after </solution>.

Example response format:
<solution>
from typing import List

def function_name(params):
    # Your implementation
    return result
</solution>
<end_of_turn>
<start_of_turn>model
"""


def make_llama_solo_prompt(task_prompt: str) -> str:
    return f"""[INST] {task_prompt}

Please provide a complete solution to the task. Encapsulate your solution within <solution> tags.

IMPORTANT: Do NOT add any explanations or commentary after the </solution> tag. End your response immediately after </solution>.

Example response format:
<solution>
from typing import List

def function_name(params):
    # Your implementation
    return result
</solution>
[/INST]"""


def make_deepseek_solo_prompt(task_prompt: str) -> str:
    return f"""<instruction>
<task>
{task_prompt}
</task>
Please provide a complete solution to the task described within the <task> tag.
Encapsulate your solution within <solution> tags. Include any necessary imports inside the <solution> tags.

IMPORTANT: Do NOT add any explanations or commentary after the </solution> tag. End your response immediately after </solution>.

Example response format:
>>> <solution>
from typing import List

def function_name(params):
    # Your implementation
    return result
</solution>
</instruction>
Your response:"""


# ── Pipeline prompts (exact from your pipeline script) ────────────────────────

def make_planning_prompt(task_prompt: str) -> str:
    return f"""Task: {task_prompt}

Write a detailed plan to solve this. Do not write code yet. Focus on:
- Algorithm approach
- Key steps
- Edge cases

Plan:"""


def extract_code_from_solution(solution: str) -> str:
    match = re.search(r'<solution>(.*?)</solution>', solution, re.DOTALL)
    if match:
        code = match.group(1).strip()
        if code.startswith('>>>'):
            code = code[3:].strip()
        if code.startswith('```python'):
            code = code[9:].strip()
        elif code.startswith('```'):
            code = code[3:].strip()
        if code.endswith('```'):
            code = code[:-3].strip()
        return code
    return solution.strip()


def make_plan_review_prompt(task_prompt: str, previous_plan: str) -> str:
    plan_content = extract_code_from_solution(previous_plan)
    return f"""<instruction>
<task>
{task_prompt}
</task>
<previousPlan>
{plan_content}
</previousPlan>
Carefully review the plan in the <previousPlan> tag for the task described in the <task> tag.

Your job is to improve this plan by thinking critically about:
1. **Algorithm correctness**: Is the approach fundamentally sound? Are there logical errors?
2. **Completeness**: Are any steps missing or vague? What needs more detail?
3. **Edge cases**: What special cases need to be handled? (empty inputs, single elements, zeros, duplicates, etc.)
4. **Data structures**: Are the right data structures being used for efficiency?
5. **Clarity**: Can the steps be explained more clearly for implementation?

Even if the plan seems good, think about how to make it MORE robust and detailed.

Provide an improved step-by-step plan (NOT code) within <solution> tags.
Example response format:
>>> <solution>
Step 1: [Improved/clarified description]
Step 2: [Improved/clarified description]
Step 3: [Additional edge case handling]
...
</solution>
</instruction>
Your response:"""


def make_coding_prompt(task_prompt: str, plan: str) -> str:
    plan_content = extract_code_from_solution(plan)
    return f"""<instruction>
<task>
{task_prompt}
</task>
<plan>
{plan_content}
</plan>
Now implement the plan described in the <plan> tag as Python code for the task in the <task> tag.

Follow the plan exactly and write clean, correct code. Include any necessary imports.

Encapsulate your code within <solution> tags. Include any necessary imports inside the <solution> tags.
Example response format:
>>> <solution>
import module_name

def function_name(...):
    # Implementation following the plan
    ...
</solution>
</instruction>
Your response:"""


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    st.set_page_config(page_title="Cross-Reflection Pipeline Demo", layout="wide")

    st.title("Cross-Reflection Pipeline Demo")
    st.markdown("**Task:** McEval Task 2 — Solo baselines vs. CodeGemma → LLaMA → DeepSeek pipeline")

    # ── Sidebar ───────────────────────────────────────────────────────────────
    st.sidebar.header("⚙️ Configuration")
    st.sidebar.markdown(f"**Planning Model:** {GEMMA_MODEL_NAME}")
    st.sidebar.markdown(f"**Review Model:** {LLAMA_MODEL_NAME}")
    st.sidebar.markdown(f"**Coding Model:** {DEEPSEEK_MODEL_NAME}")
    st.sidebar.markdown("---")

    st.sidebar.markdown("### Solo Attempts")
    temperature_solo = st.sidebar.slider("Temperature (Solo)", 0.0, 1.0, 0.0, 0.1,
                                         help="Used for all three solo attempts")
    st.sidebar.markdown("### Pipeline — Planning (CodeGemma)")
    temperature_plan = st.sidebar.slider("Temperature (Plan)", 0.0, 1.0, 0.7, 0.1)
    st.sidebar.markdown("### Pipeline — Review (LLaMA)")
    temperature_review = st.sidebar.slider("Temperature (Review)", 0.0, 1.0, 0.5, 0.1)
    st.sidebar.markdown("### Pipeline — Coding (DeepSeek)")
    temperature_code = st.sidebar.slider("Temperature (Code)", 0.0, 1.0, 0.3, 0.1)

    max_tokens = st.sidebar.slider("Max Tokens", 256, 2048, 512, 128)
    timeout    = st.sidebar.slider("Test Timeout (seconds)", 10, 120, 40, 5)

    st.sidebar.markdown("---")
    st.sidebar.markdown("### 💾 GPU Memory")
    if torch.cuda.is_available():
        if st.sidebar.button("Refresh GPU Stats"):
            pass
        try:
            total_mem     = torch.cuda.get_device_properties(0).total_memory / 1e9
            reserved_mem  = torch.cuda.memory_reserved(0) / 1e9
            allocated_mem = torch.cuda.memory_allocated(0) / 1e9
            free_mem      = total_mem - reserved_mem
            st.sidebar.text(f"Total:     {total_mem:.1f} GB")
            st.sidebar.text(f"Reserved:  {reserved_mem:.1f} GB")
            st.sidebar.text(f"Allocated: {allocated_mem:.1f} GB")
            st.sidebar.text(f"Free:      {free_mem:.1f} GB")
        except:
            st.sidebar.text("GPU info unavailable")
    else:
        st.sidebar.text("No GPU detected")

    # ── Task ──────────────────────────────────────────────────────────────────
    st.header("Task")
    try:
        task_row = load_task_2()
        col1, col2, col3 = st.columns(3)
        with col1: st.metric("Task ID", task_row['task_id'])
        with col2: st.metric("Difficulty", task_row['level'].capitalize())
        with col3: st.metric("Entry Point", task_row['entry_point'])
        with st.expander("View Task Prompt", expanded=True):
            st.text(task_row['prompt'])
    except Exception as e:
        st.error(f"Failed to load dataset: {e}")
        return

    if not st.button("🚀 Run Demo", type="primary"):
        return

    # ══════════════════════════════════════════════════════════════════════════
    # LOAD ALL MODELS UPFRONT
    # ══════════════════════════════════════════════════════════════════════════
    st.header("Loading Models")
    col1, col2, col3 = st.columns(3)

    with col1:
        gemma_tok, gemma_mdl, gemma_dev = load_model_safe(GEMMA_MODEL_NAME, GEMMA_MODEL_PATH)
        if gemma_tok is None:
            st.error(f"Failed to load {GEMMA_MODEL_NAME}"); return

    with col2:
        llama_tok, llama_mdl, llama_dev = load_model_safe(LLAMA_MODEL_NAME, LLAMA_MODEL_PATH)
        if llama_tok is None:
            cleanup_model(gemma_mdl, gemma_tok)
            st.error(f"Failed to load {LLAMA_MODEL_NAME}"); return

    with col3:
        deep_tok, deep_mdl, deep_dev = load_model_safe(DEEPSEEK_MODEL_NAME, DEEPSEEK_MODEL_PATH)
        if deep_tok is None:
            cleanup_model(gemma_mdl, gemma_tok)
            cleanup_model(llama_mdl, llama_tok)
            st.error(f"Failed to load {DEEPSEEK_MODEL_NAME}"); return

    st.success("All models loaded successfully")

    # ══════════════════════════════════════════════════════════════════════════
    # PART 1 — SOLO ATTEMPTS
    # ══════════════════════════════════════════════════════════════════════════
    st.header("Part 1: Solo Attempts")
    st.markdown("Each model attempts Task 2 independently using its own prompt format.")

    solo_results = {}

    solo_configs = [
        (GEMMA_MODEL_NAME,    gemma_tok, gemma_mdl, gemma_dev, make_gemma_solo_prompt),
        (LLAMA_MODEL_NAME,    llama_tok, llama_mdl, llama_dev, make_llama_solo_prompt),
        (DEEPSEEK_MODEL_NAME, deep_tok,  deep_mdl,  deep_dev,  make_deepseek_solo_prompt),
    ]

    for model_name, tok, mdl, dev, prompt_fn in solo_configs:
        st.subheader(f"⏳ {model_name} — Solo Attempt")

        prompt = prompt_fn(task_row['prompt'])
        st.write(f"Generating with {model_name}...")

        generated_code = generate_response(tok, mdl, dev, prompt, temperature_solo, max_tokens)

        status_icon = "⏳"
        col1, col2 = st.columns(2)

        with col1:
            st.markdown(f"**RAW Model Output ({len(generated_code)} chars):**")
            st.code(generated_code[:800] if len(generated_code) > 800 else generated_code, language="text")

        st.write(f"Running tests for {model_name}...")
        test_result = run_unit_test(generated_code, task_row['test'], task_row['entry_point'], timeout)

        with col2:
            st.markdown("**Processed Code:**")
            if test_result.get('code_tested'):
                st.code(
                    test_result['code_tested'][:800] if len(test_result['code_tested']) > 800 else test_result['code_tested'],
                    language="python"
                )
            else:
                st.warning("No code extracted")

        if test_result['passed']:
            st.success(f"✅ {model_name}: All tests passed!")
        else:
            st.error(f"❌ {model_name}: Failed — {test_result['error']}")

        solo_results[model_name] = {
            'passed':         test_result['passed'],
            'error':          test_result['error'],
            'generated_code': generated_code,
            'code_tested':    test_result['code_tested'],
        }

    # ── Solo summary ──────────────────────────────────────────────────────────
    st.subheader("Solo Attempt Summary")
    col1, col2, col3 = st.columns(3)
    for col, name in zip([col1, col2, col3],
                         [GEMMA_MODEL_NAME, LLAMA_MODEL_NAME, DEEPSEEK_MODEL_NAME]):
        r = solo_results.get(name, {})
        with col:
            st.metric(name, "PASS ✅" if r.get('passed') else "FAIL ❌")
            if not r.get('passed') and r.get('error'):
                st.caption(r['error'][:120])

    # ══════════════════════════════════════════════════════════════════════════
    # PART 2 — CROSS-REFLECTION PIPELINE
    # ══════════════════════════════════════════════════════════════════════════
    st.header("Part 2: Cross-Reflection Pipeline")
    st.markdown("**Workflow:** CodeGemma creates plan → LLaMA reviews plan → DeepSeek generates code")

    pipeline_result = {
        'plan': None, 'reviewed_plan': None,
        'generated_code': None, 'passed': False,
        'error': None, 'code_tested': None,
    }

    # ── Step 1: CodeGemma plans ───────────────────────────────────────────────
    st.subheader("Step 1: CodeGemma — Generate Plan")
    st.write("CodeGemma is generating a step-by-step plan (no code yet)...")

    plan = generate_response(gemma_tok, gemma_mdl, gemma_dev, make_planning_prompt(task_row['prompt']), temperature_plan, max_tokens)

    if not plan:
        st.error("CodeGemma failed to generate a plan.")
        cleanup_model(gemma_mdl, gemma_tok)
        cleanup_model(llama_mdl, llama_tok)
        cleanup_model(deep_mdl, deep_tok)
        return

    pipeline_result['plan'] = plan
    st.success(f"Plan generated ({len(plan)} chars)")
    with st.expander("View CodeGemma Plan", expanded=True):
        st.text(plan)

    # ── Step 2: LLaMA reviews ────────────────────────────────────────────────
    st.subheader("Step 2: Code LLaMA — Review & Improve Plan")
    st.write("LLaMA is reviewing and improving CodeGemma's plan...")

    reviewed_plan = generate_response(llama_tok, llama_mdl, llama_dev,
                                  make_plan_review_prompt(task_row['prompt'], plan),
                                  temperature_review, max_tokens)

    if not reviewed_plan:
        st.warning("LLaMA returned empty output — using original plan as fallback.")
        reviewed_plan = plan

    pipeline_result['reviewed_plan'] = reviewed_plan

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"**Original Plan — CodeGemma ({len(plan)} chars):**")
        st.text(plan)
    with col2:
        st.markdown(f"**Reviewed Plan — LLaMA ({len(reviewed_plan)} chars):**")
        st.text(reviewed_plan)

    # ── Step 3: DeepSeek codes ────────────────────────────────────────────────
    st.subheader("Step 3: DeepSeek Coder — Implement from Reviewed Plan")
    st.write("DeepSeek is implementing the reviewed plan...")

    generated_code = generate_response(deep_tok, deep_mdl, deep_dev,
                                   make_coding_prompt(task_row['prompt'], reviewed_plan),
                                   temperature_code, max_tokens)

    if not generated_code:
        st.error("DeepSeek failed to generate code.")
        cleanup_model(gemma_mdl, gemma_tok)
        cleanup_model(llama_mdl, llama_tok)
        cleanup_model(deep_mdl, deep_tok)
        return

    pipeline_result['generated_code'] = generated_code

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"**RAW Model Output ({len(generated_code)} chars):**")
        st.code(generated_code[:800] if len(generated_code) > 800 else generated_code, language="text")

    st.write("Running tests on pipeline output...")
    test_result = run_unit_test(generated_code, task_row['test'], task_row['entry_point'], timeout)

    pipeline_result['passed']      = test_result['passed']
    pipeline_result['error']       = test_result['error']
    pipeline_result['code_tested'] = test_result['code_tested']

    with col2:
        st.markdown("**Processed Code:**")
        if test_result.get('code_tested'):
            st.code(
                test_result['code_tested'][:800] if len(test_result['code_tested']) > 800 else test_result['code_tested'],
                language="python"
            )
        else:
            st.warning("No code extracted")

    if test_result['passed']:
        st.success("✅ Pipeline: All tests passed!")
    else:
        st.error(f"❌ Pipeline: Failed — {test_result['error']}")

    # ── Cleanup ───────────────────────────────────────────────────────────────
    cleanup_model(gemma_mdl, gemma_tok)
    cleanup_model(llama_mdl, llama_tok)
    cleanup_model(deep_mdl, deep_tok)

    # ══════════════════════════════════════════════════════════════════════════
    # FINAL COMPARISON
    # ══════════════════════════════════════════════════════════════════════════
    st.header("Final Results — Task 2")

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("CodeGemma (Solo)",  "PASS ✅" if solo_results.get(GEMMA_MODEL_NAME,    {}).get('passed') else "FAIL ❌")
    with col2:
        st.metric("LLaMA (Solo)",      "PASS ✅" if solo_results.get(LLAMA_MODEL_NAME,    {}).get('passed') else "FAIL ❌")
    with col3:
        st.metric("DeepSeek (Solo)",   "PASS ✅" if solo_results.get(DEEPSEEK_MODEL_NAME, {}).get('passed') else "FAIL ❌")
    with col4:
        st.metric("GLD Pipeline",      "PASS ✅" if pipeline_result['passed'] else "FAIL ❌")

    # ── Export ────────────────────────────────────────────────────────────────
    st.header("💾 Export Results")
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    def to_serializable(obj):
        if isinstance(obj, dict):   return {k: to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list): return [to_serializable(i) for i in obj]
        elif hasattr(obj, 'item'):  return obj.item()
        elif hasattr(obj, 'tolist'): return obj.tolist()
        return obj

    export_data = {
        'workflow':          'CodeGemma (Plan) → LLaMA (Review) → DeepSeek (Code)',
        'timestamp':         timestamp,
        'task_id':           task_row['task_id'],
        'task_level':        task_row['level'],
        'temperature_solo':  float(temperature_solo),
        'temperature_plan':  float(temperature_plan),
        'temperature_review': float(temperature_review),
        'temperature_code':  float(temperature_code),
        'max_tokens':        int(max_tokens),
        'timeout':           int(timeout),
        'solo_results': to_serializable({
            'gemma':    solo_results.get(GEMMA_MODEL_NAME,    {}),
            'llama':    solo_results.get(LLAMA_MODEL_NAME,    {}),
            'deepseek': solo_results.get(DEEPSEEK_MODEL_NAME, {}),
        }),
        'pipeline_result': to_serializable(pipeline_result),
    }

    st.download_button(
        label="📥 Download Full Results (JSON)",
        data=json.dumps(export_data, indent=2),
        file_name=f"cross_reflection_demo_{timestamp}.json",
        mime="application/json"
    )


if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    main()