from transformers import AutoTokenizer, AutoModelForCausalLM
import torch, time
model_name = "bigcode/starcoder2-7b"

start = time.time()
tokenizer = AutoTokenizer.from_pretrained(model_name, token=True)
model = AutoModelForCausalLM.from_pretrained(
        model_name,
            device_map="auto",
                dtype=torch.float16,
                    token=True
)

prompt = (
        "### Instruction:\n"
            "Write a Java function that performs a bubble sort on the list [1,23,64,87,25,99,14].\n\n"
                "### Response:\n"
)

inputs = tokenizer(prompt, return_tensors="pt")
inputs = {k: v.to(model.device) for k, v in inputs.items()}

print("Running Inference...")


outputs = model.generate(
        **inputs,
            max_new_tokens=200,
                eos_token_id=tokenizer.eos_token_id,
                    pad_token_id=tokenizer.eos_token_id,
)

result = tokenizer.decode(outputs[0], skip_special_tokens=True)
print("\nGenerated Code:\n")
print(result.strip())
print(f"\nTime taken: {time.time() - start:.2f}s")
print(f"\nGPU memory allocated: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
print(model_name)