import streamlit as st
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch, gc, time

# ================== CONFIG ==================
st.set_page_config(page_title="SLM Studio", layout="wide")

MODELS = {
    "DeepSeek Coder 7B Instruct": "deepseek-ai/deepseek-coder-7b-instruct-v1.5",
    "CodeGemma Instruct": "google/codegemma-7b-it",
    "CodeQwen 1.5 7B": "Qwen/CodeQwen1.5-7B",
    "Code Llama Instruct": "codellama/CodeLlama-7b-Instruct-hf"
}


st.title("Small Language Model Studio")
st.caption("Test and compare different coding models")

# ================== SIDEBAR ==================
st.sidebar.header("Model Selection")
model_name = st.sidebar.selectbox("Select Model", list(MODELS.keys()))
selected_model = MODELS[model_name]

st.sidebar.divider()
st.sidebar.subheader("Generation Parameters")
temperature = st.sidebar.slider("Temperature", 0.0, 1.0, 0.3, 0.1)
max_tokens = st.sidebar.slider("Max New Tokens", 50, 500, 200)

st.sidebar.divider()

# ================== CLEAR CACHE ==================
if st.sidebar.button("Clear GPU Cache"):
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    st.sidebar.success("GPU cache cleared")

if st.sidebar.button("Clear HuggingFace Cache"):
    import os
    import shutil
    cache_dir = os.path.expanduser("~/.cache/huggingface/hub")
    if os.path.exists(cache_dir):
        try:
            size_before = 0
            for dirpath, _, filenames in os.walk(cache_dir):
                for filename in filenames:
                    try:
                        file_path = os.path.join(dirpath, filename)
                        if os.path.exists(file_path):
                            size_before += os.path.getsize(file_path)
                    except (OSError, FileNotFoundError):
                        continue
            size_before_gb = size_before / (1024**3)
            
            # Remove all cached models
            for item in os.listdir(cache_dir):
                item_path = os.path.join(cache_dir, item)
                try:
                    if os.path.isdir(item_path):
                        shutil.rmtree(item_path)
                    else:
                        os.remove(item_path)
                except Exception as e:
                    continue
            
            st.sidebar.success(f"Cleared {size_before_gb:.2f} GB")
        except Exception as e:
            st.sidebar.error(f"Error: {e}")
    else:
        st.sidebar.info("No cache found")

# Display GPU info
if torch.cuda.is_available():
    st.sidebar.divider()
    st.sidebar.info(f"🖥️ GPU: {torch.cuda.get_device_name(0)}")

# ================== MODEL LOADING ==================
def load_model(model_name):
    import os
    os.environ["ACCELERATE_USE_FSDP"] = "false"
    os.environ["ACCELERATE_USE_DEEPSPEED"] = "false"
    
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        trust_remote_code=True,
        low_cpu_mem_usage=False,
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
    )
    
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device)
    
    return tokenizer, model

# ================== PROMPT INPUT ==================
st.header("Enter Your Task")
prompt = st.text_area(
    "Coding task:",
    height=200,
)

# ================== GENERATE BUTTON ==================
if st.button("Generate", type="primary"):
    if not prompt.strip():
        st.warning("Enter a task")
    else:
        with st.spinner(f"Generating with {model_name}..."):
            start = time.time()

            # Free GPU memory
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

            # Load model
            try:
                tokenizer, model = load_model(selected_model)
                device = next(model.parameters()).device

                with torch.no_grad():
                    # Tokenize input
                    inputs = tokenizer(prompt, return_tensors="pt").to(device)
                    if "token_type_ids" in inputs:
                        del inputs["token_type_ids"]
                    
                    # Get prompt length
                    prompt_length = inputs["input_ids"].shape[1]

                    # Generate
                    outputs = model.generate(
                        **inputs,
                        max_new_tokens=max_tokens,
                        temperature=temperature,
                        do_sample=True if temperature > 0 else False,
                        eos_token_id=tokenizer.eos_token_id,
                        pad_token_id=tokenizer.pad_token_id if tokenizer.pad_token_id else tokenizer.eos_token_id,
                        repetition_penalty=1.2,
                    )
                    
                    # Decode only generated tokens
                    generated_tokens = outputs[0][prompt_length:]
                    result = tokenizer.decode(generated_tokens, skip_special_tokens=True)
                    
                    # Combine prompt + generation
                    full_result = prompt + result

                # ================== OUTPUT ==================
                st.success("Generation complete")
                
                st.subheader("Generated Code:")
                st.code(full_result, language="python")
                
                # Metrics
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Time", f"{time.time() - start:.2f}s")
                with col2:
                    st.metric("Tokens Generated", len(generated_tokens))
                with col3:
                    if torch.cuda.is_available():
                        st.metric("GPU Memory", f"{torch.cuda.memory_allocated() / 1e9:.2f} GB")

            except Exception as e:
                st.error(f"Error: {e}")
            
            finally:
                # Unload model
                try:
                    del model
                    del tokenizer
                    gc.collect()
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                except:
                    pass

