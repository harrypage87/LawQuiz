from transformers import AutoTokenizer, AutoModelForCausalLM
import torch, time
model_name = "deepseek-ai/deepseek-coder-6.7b-instruct"

start = time.time()
tokenizer = AutoTokenizer.from_pretrained(model_name, token=True)
model = AutoModelForCausalLM.from_pretrained(
        model_name,
            device_map="auto",
                dtype=torch.float16,
                    token=True
)

prompt = ("""
    def has_close_elements(numbers: List[float], threshold: float) -> bool:
    for idx, elem in enumerate(numbers):
        for idx2, elem2 in enumerate(numbers):
            if idx != idx2:
                distance = abs(elem - elem2)
                if distance < threshold:
                    return True

    return False
Provide a concise natural language description (docstring) of the Python code in English using at most 500 characters.
    """
)

inputs = tokenizer(prompt, return_tensors="pt")
inputs = {k: v.to(model.device) for k, v in inputs.items()}

print("Running Inference...")

outputs = model.generate(
        **inputs,
            max_new_tokens=200,
                eos_token_id=tokenizer.eos_token_id,
                    pad_token_id=tokenizer.eos_token_id,
)

result = tokenizer.decode(outputs[0], skip_special_tokens=True)
print(result.strip())
print(f"\nTime taken: {time.time() - start:.2f}s")
print(f"\nGPU memory allocated: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
print(model_name)

